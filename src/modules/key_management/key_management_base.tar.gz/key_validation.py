# src/modules/key_management/key_validation.py

"""
Key Validation Module for FractalAuth

This module provides functionalities to validate SSH keys.
It ensures that generated or provided keys conform to the specified types and sizes.
Additionally, it checks for passphrase protection where necessary to enforce security standards.
"""

from .key_generation import KeyGenerator
from typing import Tuple

class KeyValidator:
    def __init__(self, key_generator: KeyGenerator):
        """
        Initialize the KeyValidator with a KeyGenerator instance to access valid key types and sizes.

        Args:
            key_generator (KeyGenerator): An instance of KeyGenerator to retrieve validation parameters.
        """
        # TODO: Store the key_generator instance for accessing valid_key_types and key sizes
        self.key_generator = key_generator
    
    def validate_key_type(self, key_type: str) -> bool:
        """
        Validate whether the provided key type is supported.

        Args:
            key_type (str): The SSH key type to validate.

        Returns:
            bool: True if valid, False otherwise.
        """
        # TODO: Check if key_type is in key_generator.valid_key_types
        return key_type in self.key_generator.valid_key_types
    
    def validate_key_size(self, key_type: str, key_size: int) -> bool:
        """
        Validate whether the provided key size is valid for the given key type.

        Args:
            key_type (str): The SSH key type.
            key_size (int): The size of the SSH key in bits.

        Returns:
            bool: True if valid, False otherwise.
        """
        # TODO: Retrieve valid sizes for key_type from key_generator
        #       Check if key_size is in the list of valid sizes
        try:
            valid_sizes = self.key_generator.list_valid_key_sizes(key_type)
            return key_size in valid_sizes
        except ValueError:
            return False
    
    def validate_private_key(self, private_key: str, passphrase: Optional[str] = None) -> bool:
        """
        Validate the provided private SSH key, ensuring it conforms to type, size, and passphrase protection.

        Args:
            private_key (str): The private SSH key to validate.
            passphrase (Optional[str]): The passphrase used to encrypt the private key, if any.

        Returns:
            bool: True if the key is valid and properly protected, False otherwise.

        Raises:
            ValueError: If the private_key format is invalid or does not meet security standards.
        """
        # TODO: Parse the private_key to determine its type and size
        #       Use validate_key_type and validate_key_size to ensure compliance
        #       Check if the key is encrypted with a passphrase if required
        #       Handle exceptions if key parsing fails
        pass
    
    def validate_public_key(self, public_key: str) -> bool:
        """
        Validate the provided public SSH key, ensuring it conforms to type and size specifications.

        Args:
            public_key (str): The public SSH key to validate.

        Returns:
            bool: True if the key is valid, False otherwise.

        Raises:
            ValueError: If the public_key format is invalid or does not meet security standards.
        """
        # TODO: Parse the public_key to determine its type and size
        #       Use validate_key_type and validate_key_size to ensure compliance
        #       Handle exceptions if key parsing fails
        pass
