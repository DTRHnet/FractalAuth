# src/modules/key_management/key_generation.py

"""
Key Generation Module for FractalAuth

This module provides functionalities to generate SSH key pairs securely.
Users can choose from predefined key types and sizes to ensure compatibility and security.
It also supports generating keys with optional passphrase protection to enhance security.
"""

from typing import Tuple, Optional

class KeyGenerator:
    def __init__(self):
        """
        Initialize the KeyGenerator with predefined valid key types and sizes.
        """
        # Define a set of valid SSH key types (e.g., RSA, DSA, ECDSA, ED25519)
        self.valid_key_types = {
            'RSA': [2048, 3072, 4096],
            'DSA': [1024, 2048],
            'ECDSA': [256, 384, 521],
            'ED25519': [256]  # ED25519 typically uses a fixed size
        }
    
    def list_valid_key_types(self) -> list:
        """
        List all valid SSH key types supported by FractalAuth.

        Returns:
            List[str]: A list of valid SSH key types.
        """
        # TODO: Return a list of valid key types from self.valid_key_types
        return list(self.valid_key_types.keys())
    
    def list_valid_key_sizes(self, key_type: str) -> list:
        """
        List all valid SSH key sizes for a given key type.

        Args:
            key_type (str): The type of SSH key (e.g., RSA, DSA).

        Returns:
            List[int]: A list of valid key sizes for the specified key type.

        Raises:
            ValueError: If the provided key_type is not supported.
        """
        # TODO: Check if key_type is in self.valid_key_types
        #       If yes, return the list of valid sizes
        #       If not, raise a ValueError with an appropriate message
        if key_type not in self.valid_key_types:
            raise ValueError(f"Unsupported key type: {key_type}. Supported types are: {', '.join(self.valid_key_types.keys())}")
        return self.valid_key_types[key_type]
    
    def generate_key_pair(self, key_type: str, key_size: int, passphrase: Optional[str] = None) -> Tuple[str, str]:
        """
        Generate an SSH key pair based on the specified type and size, with optional passphrase protection.

        Args:
            key_type (str): The type of SSH key to generate (e.g., RSA, DSA).
            key_size (int): The size of the SSH key in bits.
            passphrase (Optional[str]): An optional passphrase to protect the private key.

        Returns:
            Tuple[str, str]: A tuple containing the private key and public key as strings.

        Raises:
            ValueError: If the key_type or key_size is invalid.
            Exception: If key generation fails due to underlying library errors.
        """
        # TODO: Validate key_type and key_size using list_valid_key_types and list_valid_key_sizes
        #       If valid, generate the SSH key pair using appropriate libraries (e.g., cryptography)
        #       Serialize the keys into PEM or OpenSSH formats
        #       Apply passphrase protection to the private key if passphrase is provided
        #       Return the private and public keys as strings
        pass
